#include "URLSearchResultEvent.h"

URLSearchResultEvent::URLSearchResultEvent()
{
    //ctor
}
